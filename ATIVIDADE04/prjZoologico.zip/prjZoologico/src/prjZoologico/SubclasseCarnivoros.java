package prjZoologico;

public class SubclasseCarnivoros extends ClasseAnimal {
	
	//MÉTODOS DA SUBCLASSE
	//Caçar
	public void metodoCacar() {
		System.out.println(this.atributoNome + " está caçando.");
	}

}
