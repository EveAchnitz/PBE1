package prjZoologico;

public class ClasseAnimal {
	//ATRIBUTOS
	String atributoNome;
	String atributoRaca;
	String atributoSexo;
	double atributoPeso;
	
	//CONSTRUTORES
	public ClasseAnimal() {
		
	}
	public ClasseAnimal(String parametroNome, String parametroRaca, String parametroSexo, double parametroPeso) {
		this.atributoNome = parametroNome;
		this.atributoRaca = parametroRaca;
		this.atributoSexo = parametroSexo;
		this.atributoPeso = parametroPeso;
	}
	
	//MÉTODOS 
	//Comer
	public void metodoComer() {
		if (this.atributoPeso >= 170){
			System.out.println(this.atributoNome + " está obeso, deve se exercitar.");
		}
		else {
			this.atributoPeso += 10;
		}
	}
	//Exercitar 
	public void metodoExercitar() {
		if (this.atributoPeso <= 50) {
			System.out.println(this.atributoNome + " está magro demais, deve se alimentar.");
		}
		else {
			this.atributoPeso -= 10;
		}
	}
	//Exibir informações
	public void exibirInfo() {
		System.out.println("Nome: " + this.atributoNome);
		System.out.println("Peso: " + this.atributoPeso);
	}
	
}
