package prjPokemonV2;

public class Aplicacao {

	public static void main(String[] args) {
		
		//Criando os objetos
		Pokemon p1 = new PokemonFogo();
		Pokemon p2 = new PokemonFogo();
		Pokemon p3 = new PokemonAgua();
		Pokemon p4 = new PokemonAgua();
		Pokemon p5 = new PokemonVoador();
		Pokemon p6 = new PokemonVoador();
		Pokemon p7 = new Pokemon();
		Pokemon p8 = new Pokemon();
		
		//Pokémons de fogo
		p1.setNome("Charmander");
		p1.setTipo("Fogo");
		p1.setNivel(9);
		p1.setHp(110);
		p1.setDefesa(100);
		
		p1.atacar();
		p1.evoluir();
		p1.exibirInfo();
		
		p2.setNome("Charmeleon");
		p2.setTipo("Fogo");
		p2.setNivel(5);
		p2.setHp(120);
		p2.setDefesa(90);
		
		p2.atacar();
		p2.evoluir();
		p2.exibirInfo();
		
		//Pokémons de água
		p3.setNome("Wartortle");
		p3.setTipo("Água");
		p3.setNivel(8);
		p3.setHp(100);
		p3.setDefesa(80);
		
		p3.atacar();
		p3.evoluir();
		p3.exibirInfo();
		
		p4.setNome("Blastoise");
		p4.setTipo("Água");
		p4.setNivel(5);
		p4.setHp(130);
		p4.setDefesa(110);
		
		p4.atacar();
		p4.evoluir();
		p4.exibirInfo();
		
		//Pokémons voadores
		p5.setNome("Butterfree");
		p5.setTipo("Bug");
		p5.setNivel(7);
		p5.setHp(140);
		p5.setDefesa(95);
		
		p5.atacar();
		p5.evoluir();
		p5.exibirInfo();
		
		p6.setNome("Golbat");
		p6.setTipo("Poison");
		p6.setNivel(6);
		p6.setHp(105);
		p6.setDefesa(90);
		
		p6.atacar();
		p6.evoluir();
		p6.exibirInfo();

		//Pokémons normais
		p7.setNome("Ratatta");
		p7.setTipo("Normal");
		p7.setNivel(8);
		p7.setHp(100);
		p7.setDefesa(95);
		
		p7.atacar();
		p7.evoluir();
		p7.exibirInfo();
		
		p8.setNome("Raticate");
		p8.setTipo("Normal");
		p8.setNivel(6);
		p8.setHp(110);
		p8.setDefesa(90);
		
		p8.atacar();
		p8.evoluir();
		p8.exibirInfo();
	}

}
