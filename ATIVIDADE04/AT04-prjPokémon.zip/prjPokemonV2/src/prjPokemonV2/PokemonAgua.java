package prjPokemonV2;

public class PokemonAgua extends Pokemon {
	
	//MÉTODOS DA SUBCLASSE
	@Override 
	public void atacar() {
		System.out.println(this.getNome() + " lançou ataques!");
	}
	public void surfar() {
		System.out.println(this.getNome() + " está surfando!");
	}
	public void canhaoAgua() {
		System.out.println(this.getNome() + " está lançando água nos canhões!");
	}

}
