package prjPokemonV2;

public class PokemonVoador extends Pokemon {
	
	//MÉTODOS DA SUBCLASSE
	@Override
	public void atacar() {
		System.out.println(this.getNome() + " lançou ataques do céu!");
	}
	public void voar() {
		System.out.println(this.getNome() + " está voando!");
	}
	public void ataqueDeAsa() {
		System.out.println(this.getNome() + " execultou o ataque de asa com sucesso!");
	}

}
