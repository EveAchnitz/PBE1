package prjPokemonV2;

public class Pokemon {
	//ATRIBUTOS
	private String nome;
	private String tipo;
	private int nivel;
	private int hp;
	private int defesa;
	
	//CONSTRUTORES
	public Pokemon() {
		
	}
	public Pokemon(String nome, String tipo, int nivel, int hp, int defesa) {
		this.nome = nome;
		this.tipo = tipo;
		this.nivel = nivel;
		this.hp = hp;
		this.defesa = defesa;
	}
	//GETTERS E SETTERS
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public int getNivel() {
		return nivel;
	}
	public void setNivel(int nivel) {
		this.nivel = nivel;
	}
	
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	
	public int getDefesa() {
		return defesa;
	}
	public void setDefesa(int defesa) {
		this.defesa = defesa;
	}
	
	//MÉTODOS
	public void atacar() {
		System.out.println(this.nome + " atacou!");
	}
	
	public void evoluir() {
		System.out.println(this.nome + " evoluiu!");
	}
	public void exibirInfo() {
		System.out.println("Nome: " + this.nome);
		System.out.println("Tipo: " + this.tipo);
		System.out.println("Nível: " + this.nivel);
		System.out.println("Hp: " + this.hp);
		System.out.println("Defesa: " + this.defesa);
	}

}
