package prjPokemonV2;

public class PokemonFogo extends Pokemon {
	
	//MÉTODOS DA SUBCLASSE
	@Override
	public void atacar() {
		System.out.println(this.getNome() + " esquentou a situação com os seus ataques quentes!");
	}
	public void bolaFogo() {
		System.out.println("Bolas de fogo foram lançadas!");
	}
	public void explosaoFogo() {
		System.out.println("BUM!");
	}
	public void lancaChamas() {
		System.out.println("Chamas foram lançadas!");
	}

}
