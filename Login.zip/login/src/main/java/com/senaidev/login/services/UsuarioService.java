package com.senaidev.login.services;

import org.springframework.stereotype.Service;

import com.senaidev.login.entities.Usuario;

@Service
public class UsuarioService {

	//MÉTODO PARA VALIDAR OS VALORES DE USUÁRIO E SENHA
	public boolean validarLogin(Usuario usuario) { //true or false
		return "admin".equals(usuario.getUsername()) && //equals compara o valor colocado aqui e o valor dos gets do usuário
				"1234".equals(usuario.getPassword());// && significa que os dois valores precisam ser verdadeiros
	}
}
