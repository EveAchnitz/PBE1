package com.senaidev.login.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senaidev.login.entities.Usuario;
import com.senaidev.login.services.UsuarioService;

@RestController
@RequestMapping(value = "/login") //ENDPOINT
public class LoginController {

	//ATRIBUTO PARA VALIDAÇÃO
	@Autowired //alguma coisa de dependência
	private UsuarioService usuarioService;
	
	//MÉTODO PARA RESPOSTA HTTP DA REQUISIÇÃO
	@PostMapping
	public ResponseEntity<String> login(@RequestBody Usuario usuario){ //mostra que o usuario é o body (onde tudo será armazenado)
		boolean isValid = usuarioService.validarLogin(usuario); //chama o método validarLogin e a variável isValid armazena o resultado (true or false)
		
		if(isValid) {
			return ResponseEntity.ok("Login feito com sucesso :)!");
		}
		else {
			return ResponseEntity.status(401).body("Credenciais inválidas.");
		}
	}

}