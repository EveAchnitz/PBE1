package com.senaidev.cadastroproduto.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senaidev.cadastroproduto.entities.Produto;
import com.senaidev.cadastroproduto.repositories.ProdutoRepository;

@Service
public class ProdutoService {

	//ATRIBUTOS
	@Autowired
	private ProdutoRepository produtoRepository;
	
	//MÉTODO QUE PEGA AS FUNÇÕES DO JPA
	public Produto saveProduto(Produto produto) {
		return produtoRepository.save(produto); //salva o produto no banco de dados
	}
	
	//MÉTODO QUE COLOCA TODOS OS PRODUTOS EM UMA LISTA
	public List<Produto> getAllProdutos(){
		return produtoRepository.findAll(); 
	}
	
	//MÉTODO QUE PEGA OS PRODUTOS PELO ID
	public Produto getProdutoById(long id) {
		return produtoRepository.findById(id).orElse(null);
	}
	
	//MÉTODO PARA DELETAR UM PRODUTO
	public void deleteProduto(long id) {
		produtoRepository.deleteById(id);
	}
}
