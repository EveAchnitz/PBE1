package com.senaidev.cadastroproduto.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senaidev.cadastroproduto.entities.Produto;
import com.senaidev.cadastroproduto.services.ProdutoService;

@RestController
@RequestMapping(value = "/produtos")
public class ProdutoController {
	
	//ATRIBUTOS
	@Autowired
	private ProdutoService produtoService;
	
	//MÉTODO POST
	@PostMapping
	public Produto createProduto(@RequestBody Produto produto) {
		return produtoService.saveProduto(produto);
	}
	
	//MÉTODO GET
	@GetMapping
	public List<Produto> getAllProdutos(){
		return produtoService.getAllProdutos();
	}

	//MÉTODO QUE PEGA O PRODUTO PELO ID
	@GetMapping("/{id}") //isso mostra pro método que o endpoint dele é de um id
	public Produto getProduto(@PathVariable Long id) {
		return produtoService.getProdutoById(id);
	}
	
	//MÉTODO QUE DELETA 
	@DeleteMapping("/{id}")
	public void deleteProduto(@PathVariable Long id) { //especifica a pasta em que o dado será pesquisado
		produtoService.deleteProduto(id);
	}
}
