package br.com.bibliotecasenai.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import br.com.bibliotecasenai.entities.Livro;
import br.com.bibliotecasenai.repositories.LivroRepository;

public class LivroService {

	//ATRIBUTOS
	@Autowired
	private LivroRepository livroRepository;
	
	//MÉTODOS
	//SALVAR OS LIVROS
	public Livro saveLivro(Livro livro){
		return livroRepository.save(livro);
	}
	
	//PEGAR TODOS OS LIVROS EM LISTA
	public List<Livro> getAllLivros(){
		return livroRepository.findAll();
	}
	
	//PEGAR OS LIVROS PELO ID
	public Livro getLivroById(long id) {
		return livroRepository.findById(id).orElse(null);
	}
	
	//DELETAR OS LIVROS PELO ID
	public void deleteLivro(long id) {
		livroRepository.deleteById(id);
	}
}
