package br.com.bibliotecasenai.principal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.bibliotecasenai.principal.entities.Livro;

public interface LivroRepository extends JpaRepository<Livro, Long>{

}
