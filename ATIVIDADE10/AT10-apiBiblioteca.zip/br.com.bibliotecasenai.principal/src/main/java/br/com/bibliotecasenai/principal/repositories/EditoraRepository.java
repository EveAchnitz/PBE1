package br.com.bibliotecasenai.principal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.bibliotecasenai.principal.entities.Editora;

public interface EditoraRepository extends JpaRepository<Editora, Long>{

}
