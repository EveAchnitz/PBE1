package br.com.bibliotecasenai.principal.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.bibliotecasenai.principal.entities.Livro;
import br.com.bibliotecasenai.principal.services.LivroService;

@RestController
@RequestMapping("/livros")
public class LivroController {

	//ATRIBUTOS
	private LivroService livroService = new LivroService();
	
	//MÉTODOS
	//POST
	@PostMapping
	public Livro createLivros(@RequestBody Livro livro) {
		return livroService.saveLivro(livro);
	}
	
	//GET
	@GetMapping
	public List<Livro> getAllLivros(){
		return livroService.getAllLivros();
	}
	
	//GET PELO ID
	@GetMapping("/{id}")
	public Livro getLivro(@PathVariable Long id) {
		return livroService.getLivroById(id);
	}
	
	//DELETE
	@DeleteMapping("/{id}")
	public void deleteLivro(@PathVariable Long id) {
		livroService.deleteLivro(id);
	}
}
