package br.com.bibliotecasenai.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_editora")
public class Editora {

	//ATRIBUTOS
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_editora;
	
    @Column(name = "nome")
	private String nome_editora;
    
    @Column(name = "cnpj")
	private String cnpj;
    
    @Column(name = "email")
	private String email;
    
    @Column(name = "contato")
	private String contato;
	
	//CONSTRUTORES
	public Editora() {
		
	}
	public Editora(Long idEditora, String nomeEditora, String cnpj, String email, String contato) {
		this.id_editora = idEditora;
		this.nome_editora = nomeEditora;
		this.cnpj = cnpj;
		this.email = email;
		this.contato = contato;
	}
	
	//GETTERS E SETTERS
	public Long getIdEditora() {
		return id_editora;
	}
	public void setIdEditora(Long idEditora) {
		this.id_editora = idEditora;
	}
	public String getNomeEditora() {
		return nome_editora;
	}
	public void setNomeEditora(String nomeEditora) {
		this.nome_editora = nomeEditora;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContato() {
		return contato;
	}
	public void setContato(String contato) {
		this.contato = contato;
	}
	
}
