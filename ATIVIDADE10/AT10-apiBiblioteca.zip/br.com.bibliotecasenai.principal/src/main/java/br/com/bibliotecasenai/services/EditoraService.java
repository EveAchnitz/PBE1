package br.com.bibliotecasenai.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.bibliotecasenai.entities.Editora;
import br.com.bibliotecasenai.repositories.EditoraRepository;

@Service
public class EditoraService {

	//ATRIBUTOS
	@Autowired
	private EditoraRepository editoraRepository;
	
	//MÉTODOS
	//SALVAR AS EDITORAS
	public Editora saveEditora(Editora editora) {
		return editoraRepository.save(editora);
	}
	
	//PEGAR TODAS AS EDITORAS EM LISTA
	public List<Editora> getAllEditoras(){
		return editoraRepository.findAll();
	}
	
	//PEGAR AS EDITORAS PELO ID
	public Editora getEditoraById(long id) {
		return editoraRepository.findById(id).orElse(null);
	}
	
	//DELETAR AS EDITORAS
	public void deleteEditora(long id) {
		editoraRepository.deleteById(id);
	}
}
