package prjExercicio04;

public class Veiculo {
	
	//ATRIBUTOS
	String marca;
	String modelo;
	int velocidade;
	
	//CONSTRUTORES
	public Veiculo() {
		
	}
	public Veiculo(String marca, String modelo, int velocidade) {
		this.marca = marca;
		this.modelo = modelo;
		this.velocidade = velocidade;
	}
	
	//MÉTODOS
	public void acelerar() {
		velocidade += 10;
		System.out.println("Veículo acelerando");
	}
	
	public void frear() {
		velocidade -= 10;
		System.out.println("Veículo freando");
	}

}
