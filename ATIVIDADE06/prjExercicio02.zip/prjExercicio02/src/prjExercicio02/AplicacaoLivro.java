package prjExercicio02;

public class AplicacaoLivro {

	public static void main(String[] args) {
		
		//OBJETOS
		Livro livro01 = new Livro();
		livro01.setTitulo("Matilda");
		livro01.setAutor("Roald Dahl");
		livro01.setNumPaginas(105);
		livro01.setPreco(25.00);
		
		Livro livro02 = new Livro();
		livro02.setTitulo("Lorax");
		livro02.setAutor("Doctor Seuss");
		livro02.setNumPaginas(47);
		livro02.setPreco(20.50);
		
		Livro livro03 = new Livro();
		livro03.setTitulo("Alice no país das maravilhas");
		livro03.setAutor("Lewis Carrol");
		livro03.setNumPaginas(215);
		livro03.setPreco(30.00);
		
		//Métodos
		livro01.exibirInfo();
		livro02.exibirInfo();
		livro03.exibirInfo();
		
		livro01.aplicarDesconto();
		livro02.aplicarDesconto();
		livro03.aplicarDesconto();
		
		//Depois do desconto
		livro01.exibirInfo();
		livro02.exibirInfo();
		livro03.exibirInfo();
	}

}
