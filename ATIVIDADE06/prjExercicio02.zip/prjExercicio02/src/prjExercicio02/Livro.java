package prjExercicio02;

public class Livro {

	//ATRIBUTOS
	private String titulo;
	private String autor;
	private int numPaginas;
	private double preco;
	
	//CONSTRUTORES
	public Livro() {
		
	}
	public Livro(String titulo, String autor, int numPaginas, double preco) {
		this.titulo = titulo;
		this.autor = autor;
		this.numPaginas = numPaginas;
		this.preco = preco;
	}
	
	//GETTERS E SETTERS
	//Título
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	//Autor
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	//Número de páginas
	public int getNumPaginas() {
		return numPaginas;
	}
	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}
	//Preço
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	//MÉTODOS
	//Aplicar desconto de R$15,00
	public void aplicarDesconto() {
		preco -= 15;
	}
	//Exibir as novas informações
	public void exibirInfo() {
		System.out.println("Título do livro: "+ this.titulo + ";");
		System.out.println("Autor: "+ this.autor+ ";");
		System.out.println("Número de páginas: "+ this.numPaginas + ";");
		System.out.println("Preço: "+ this.preco + ";");
		System.out.println(" ");
	}
		
}
