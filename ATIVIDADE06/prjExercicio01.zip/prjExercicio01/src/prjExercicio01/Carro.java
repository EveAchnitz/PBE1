package prjExercicio01;

public class Carro {
	
	//ATRIBUTOS
	String marca;
	String modelo;
	int ano;
	String placa;
	
	//CONSTRUTORES
	public Carro() {
		
	}
	public Carro(String marca, String modelo, int ano, String placa) {
		this.marca = marca;
		this.modelo = modelo;
		this.ano = ano;
		this.placa = placa;
	}
	
	//MÉTODOS
	//Exibir informações
	public void exibirInfo() {
		System.out.println("Marca: "+ this.marca + ";");
		System.out.println("Modelo: "+ this.modelo + ";");
		System.out.println("Ano: " + this.ano + ";");
		System.out.println("Placa: " + this.placa + ";");
		System.out.println(" ");
	}

}
