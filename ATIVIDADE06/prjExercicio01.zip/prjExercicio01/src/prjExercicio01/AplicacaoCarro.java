package prjExercicio01;

public class AplicacaoCarro {

	public static void main(String[] args) {
		
		//OBJETOS
		Carro carro01 = new Carro("Volkswagen", "Gol", 2011, "ADFR56EA");
		Carro carro02 = new Carro("Fiat", "City", 2018, "HSNF28UE");
		
		//Métodos
		carro01.exibirInfo();
		carro02.exibirInfo();
	}

}
