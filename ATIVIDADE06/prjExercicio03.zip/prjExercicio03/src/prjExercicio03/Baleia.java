package prjExercicio03;

public class Baleia extends Animal{
	
	//MÉTODOS DA SUBCLASSE
	public void nadar() {
		System.out.println("Continue a nadar!");
	}

}
