package prjExercicio03;

public class Leao extends Animal{
	
	//MÉTODOS DA SUBCLASSE
	public void cacar() {
		System.out.println("O leão está caçando!");
	}

}
