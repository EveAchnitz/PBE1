package prjExercicio05;

public class ContaPoupanca extends ContaBancaria{
	
	//ATRIBUTOS
	double taxaJuros;
	
	//MÉTODOS
	public void calcularJuros(int meses) {
		setSaldo(getSaldo() + (meses * taxaJuros));
	}
}
