package prjExercicio05;

public class ContaBancaria {
	
	//ATRIBUTOS
	private int numero;
	private String titular;
	private double saldo;
	
	//CONSTRUTORES
	public ContaBancaria() {
		
	}
	public ContaBancaria(int numero, String titular, double saldo) {
		this.numero = numero;
		this.titular = titular;
		this.saldo = saldo;
	}
	
	//GETTERS E SETTERS
	//Número
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	//Titular
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	//Saldo
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	//MÉTODOS
	public void depositar(double valor) {
		saldo += valor;
	}
	public void sacar(double valor) {
		if(valor <= 500) {
			if(saldo >= valor) {
			saldo -= valor;
			}
			else {
			System.out.println("Não há saldo suficiente para sacar.");
			}
		}
		else {
			System.out.println("Não é possível sacar valores superiores a R$500,00.");
		}
	}
}
