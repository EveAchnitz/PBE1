package br.com.cursos.principal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cursos.principal.entities.Turma;

public interface TurmaRepository extends JpaRepository<Turma, Long>{

}
