package br.com.cursos.principal.entities;

import jakarta.persistence.Column; 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_turma")
public class Turma {

	//ATRIBUTOS
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idTurma;
	
	@Column(name = "data início")
	private String dataInicio;
	
	@Column(name = "data término")
	private String dataTermino;
	
	@Column(name = "horário das aulas")
	private String horarioAulas;
	
	@Column(name = "vagas disponíveis")
	private int vagasDisponiveis;
	
	//CONSTRUTORES
	public Turma() {
		
	}
	public Turma(int idTurma, String dataInicio, String dataTermino, String horarioAulas, int vagasDisponiveis) {
		this.idTurma = idTurma;
		this.dataInicio = dataInicio;
		this.dataTermino = dataTermino;
		this.horarioAulas = horarioAulas;
		this.vagasDisponiveis = vagasDisponiveis;
	}
	
	//GETTERS E SETTERS
	public String getDataInicio() {
		return dataInicio;
	}
	public void setDataInicio(String dataInicio) {
		this.dataInicio = dataInicio;
	}
	public String getDataTermino() {
		return dataTermino;
	}
	public void setDataTermino(String dataTermino) {
		this.dataTermino = dataTermino;
	}
	public String getHorarioAulas() {
		return horarioAulas;
	}
	public void setHorarioAulas(String horarioAulas) {
		this.horarioAulas = horarioAulas;
	}
	public int getVagasDisponiveis() {
		return vagasDisponiveis;
	}
	public void setVagasDisponiveis(int vagasDisponiveis) {
		this.vagasDisponiveis = vagasDisponiveis;
	}
}
