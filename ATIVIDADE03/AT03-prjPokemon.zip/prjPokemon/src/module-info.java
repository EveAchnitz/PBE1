/**
 * 
 */
/**
 * 
 */
module prjPokemon {
}