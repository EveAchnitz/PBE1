package prjPokemon;

public class Pokemon {
	
	//ATRIBUTOS
	String nome;
	String tipo;
	double nivel;
	int hp; //vida do Pokemón
	
	//CONSTRUTORES
	public Pokemon() {
		
	}
	public Pokemon(String nome, String tipo, double nivel, int hp) {
		this.nome = nome;
		this.tipo = tipo;
		this.nivel = nivel;
		this.hp = hp;
	}
	
	//MÉTODOS
	public void atacar() {
		System.out.println(this.nome + " executou o ataque com sucesso!");
	}
	public void evoluir() {
		System.out.println(this.nome + " evoluiu, parabéns!!!");
	}

}
