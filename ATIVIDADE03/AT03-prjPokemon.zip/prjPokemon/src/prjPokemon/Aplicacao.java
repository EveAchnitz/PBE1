package prjPokemon;

public class Aplicacao {

	public static void main(String[] args) {
		
		Pokemon p1 = new Pokemon("Pikachu", "Electric", 14, 70);
		Pokemon p2 = new Pokemon("Raichu", "Electric", 10, 120);
		Pokemon p3 = new Pokemon("Jigglypuff", "Fairy", 12, 70);
		Pokemon p4 = new Pokemon("Vulpix", "Fire", 11, 60);
		Pokemon p5 = new Pokemon("Oddish", "Grass", 13, 50);
		
		p1.atacar();
		p1.evoluir();
		
		p2.atacar();
		p2.evoluir();
		
		p3.atacar();
		p3.evoluir();
		
		p4.atacar();
		p4.evoluir();
		
		p5.atacar();
		p5.evoluir();
	}

}
