package com.senaidev.cadastroproduto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroprodutoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroprodutoApplication.class, args);
	}

}
