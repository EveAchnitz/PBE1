package prjFuncionario;

import java.util.Scanner;

public class CadastroFuncionario {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		//Objetos
		FuncionarioClasse funcionario01 = new FuncionarioClasse();
		
		//Armazenando atributos
		System.out.print("Qual é o nome completo do funcionário?");
		funcionario01.setNomeCompleto(sc.nextLine());
		
		System.out.print("Qual é o salário bruto do funcionário?");
		funcionario01.setSalarioBruto(sc.nextDouble());
		
		System.out.print("Qual é a porcentagem do imposto?");
		funcionario01.setImposto(sc.nextDouble());
		
		//Chamando os métodos
		funcionario01.calcularImposto();
		funcionario01.calcularSalarioLiquido();
		funcionario01.aumentarSalario();
		
		//Exibição final
		System.out.println("Nome: "+ funcionario01.getNomeCompleto());
		System.out.println("Salário bruto: "+ funcionario01.getSalarioBruto());
		System.out.println("Valor do imposto: "+ funcionario01.getImposto());
		System.out.println("Salário líquido: "+ funcionario01.getSalarioLiquido());
		
		sc.close();

	}

}
