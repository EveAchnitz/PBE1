package prjFuncionario;

public class FuncionarioClasse {
	
	//ATRIBUTOS
	private String nomeCompleto;
	private double salarioBruto;
	private double imposto;
	double salarioLiquido;
	double porcentagem;
	
	//CONSTRUTORES
	public FuncionarioClasse() {
		
	}
	public FuncionarioClasse(String nomeCompleto, double salarioBruto, double imposto){
		this.nomeCompleto = nomeCompleto;
		this.salarioBruto = salarioBruto;
		this.imposto = imposto;
	}
	//GETTERS E SETTERS
	//Nome completo
	public String getNomeCompleto() {
		return nomeCompleto;
	}
	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}
	//Salário bruto
	public double getSalarioBruto() {
		return salarioBruto;
	}
	public void setSalarioBruto(double salarioBruto) {
		this.salarioBruto = salarioBruto;
	}
	//Imposto
	public double getImposto() {
		return imposto;
	}
	public void setImposto(double imposto) {
		this.imposto = imposto;
	}
	//Salário líquido
	public double getSalarioLiquido() {
		return salarioLiquido;
	}
	
	//MÉTODOS
	void calcularImposto() {
		imposto = (imposto/100) * salarioBruto;
	}
	void calcularSalarioLiquido() {
		salarioLiquido = salarioBruto - imposto;
	}
	void aumentarSalario() {
		salarioBruto += porcentagem * salarioBruto;
	}

}
