package prjBanco;

public class ContaBanco {
	
	//ATRIBUTOS
	private int numeroConta;
	private String nomeTitular;
	private double saldo;
	
	//CONSTRUTORES
	public ContaBanco() {
		
	}
	
	public ContaBanco(int numeroConta, String nomeTitular, double saldo) {
		this.numeroConta = numeroConta;
		this.nomeTitular = nomeTitular;
		this.saldo = saldo;
	}
	
	//GETTERS SETTERS
	//Número da conta
	public int getNumeroConta() {
		return numeroConta; 
	}
	public void setNumeroConta() {
		this.numeroConta = numeroConta;
	}
	//Nome do titular
	public String getNomeTitular() {
		return nomeTitular;
	}
	public void setNomeTitular() {
		this.nomeTitular = nomeTitular;
	}
	//Saldo
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo() {
		this.saldo = saldo;
	}
	
	//MÉTODOS
	void depositar() {
		
	}
	
	void sacar() {
		
	}
	
	void exibirInfo() {
		
	}
}
