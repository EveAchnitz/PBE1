package prjBanco;

public class ContaBanco {
	
	//ATRIBUTOS
	private int numeroConta;
	private String nomeTitular;
	private double saldo;
	
	//CONSTRUTORES - para iniciar o objeto
	public ContaBanco() {
		
	}
	
	public ContaBanco(int numeroConta, String nomeTitular, double saldo) {
		this.numeroConta = numeroConta;
		this.nomeTitular = nomeTitular;
		this.saldo = saldo;
	}
	
	//GETTERS SETTERS
	//Número da conta
	public int getNumeroConta() {
		return numeroConta; 
	}
	public void setNumeroConta(int numeroConta) {
		this.numeroConta = numeroConta;
	}
	//Nome do titular
	public String getNomeTitular() {
		return nomeTitular;
	}
	public void setNomeTitular(String nomeTitular) {
		this.nomeTitular = nomeTitular;
	}
	//Saldo
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	//MÉTODOS
	void depositar(double valor) {
		saldo += valor;
	}
	
	void sacar(double valor) {
		if(saldo > valor) {//Verificando se há saldo suficiente
		saldo -= valor;
		}
		else {
			System.out.println("Não há saldo suficiente.");
		}
	}
	
	void exibirInfo() {
		System.out.println("Número da conta: " + numeroConta);
		System.out.println("Nome do titular: " + nomeTitular);
		System.out.println("Saldo atual: " + saldo);
	}
}
