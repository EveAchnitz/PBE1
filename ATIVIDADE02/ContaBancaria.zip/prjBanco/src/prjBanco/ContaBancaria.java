package prjBanco;

import java.util.Scanner;

public class ContaBancaria {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		
		//Objetos
		ContaBanco conta01 = new ContaBanco();
		
		//Armazenando atributos
		System.out.print("Qual é o nome do titular? ");
		conta01.setNomeTitular(sc.nextLine());
		
		System.out.print("Qual é o número da sua conta?");
		conta01.setNumeroConta(sc.nextInt());
		
		System.out.print("Qual é o seu saldo atual?");
		conta01.setSaldo(sc.nextDouble());
		
		//Opções
		System.out.println("Podemos:");
		System.out.println("1. Depositar;");
		System.out.println("2. Sacar:");
		System.out.println("O que você deseja fazer?");
		int escolha = sc.nextInt();
		
		//Chamando os métodos
		if (escolha == 1) {
			System.out.print("Quanto você deseja depositar? ");
			conta01.depositar(sc.nextDouble());
		}
		else if (escolha == 2) {
			System.out.print("Quanto você deseja sacar? ");
			conta01.sacar(sc.nextDouble());
		}
		else {
			System.out.println("Valor inválido.");
		}
		
		//Exibição final
		conta01.exibirInfo();
		
		sc.close();

	}

}
