package prjBanco;

public class ContaBancaria {

	public static void main(String[] args) {

	}

}
