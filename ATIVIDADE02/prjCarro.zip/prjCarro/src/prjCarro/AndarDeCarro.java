package prjCarro;

import java.util.Scanner;

public class AndarDeCarro {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Qual é a marca do carro? ");
		String marca = sc.nextLine();
		
		System.out.print("Qual é o modelo do carro? ");
		String modelo = sc.nextLine();
		
		System.out.print("Qual é a velocidade do carro? ");
		int velocidade = sc.nextInt();
		
		System.out.print("Ok! Você quer acelerar (1) ou frear (2) o carro? ");
		int resposta = sc.nextInt();
		
		if(resposta == 1) {
			System.out.print("Quanto? ");
			int acelerar = sc.nextInt();
			velocidade += acelerar;
		}
		else if(resposta == 2) {
			System.out.print("Quanto? ");
			int desacelerar = sc.nextInt();
			velocidade -= desacelerar;
		}
		else {
			System.out.println("O carro se manterá na mesma velocidade.");
		}
		
		System.out.print("O carro "+ modelo + " da marca "+ marca + " está a "+ velocidade + "Km/h nesse momento.");

		sc.close();
	}

}
