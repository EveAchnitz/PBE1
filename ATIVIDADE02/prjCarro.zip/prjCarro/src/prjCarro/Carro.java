package prjCarro;

public class Carro {
	//ATRIBUTOS
	private String marca;
	private String modelo;
	private int velocidade;
	
	//CONSTRUTORES
	public Carro() {
		
	}
	public Carro(String marca, String modelo, int velocidade) {
		this.marca = marca;
		this.modelo = modelo;
		this.velocidade = velocidade;
	}
	public Carro(String marca) {
		this.marca = marca;
	}
	
	//GETTERS SETTERS
	//Marca
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	//Modelo
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	//Velocidade
	public int getVelocidade() {
		return velocidade;
	}
	public void setVelocidade(int velocidade) {
		if(velocidade < 0) {
			System.out.println("A velocidade não pode ser negativa.");
			this.velocidade = 0;
		}
		else {
			this.velocidade = velocidade;
		}
		
	}
	
	//MÉTODOS
	void acelerar(int acelerar) {
		velocidade += acelerar;
	}
	
	void frear(int desacelerar) {
		velocidade -= desacelerar;
	}
	
	void buzinar() {
		System.out.println("bii bii");
	}
}
